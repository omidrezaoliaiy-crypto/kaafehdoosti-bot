# -*- coding: utf-8 -*-
"""
موتور شبیه‌ساز معاملات (Paper Trading Engine)
اجرای معاملات فرضی با قیمت‌های زنده و عمق اردربوک واقعی نوبیتکس
"""

import time
from typing import Dict, List, Optional
try:
    from .database import (
        get_paper_balance,
        update_paper_balance,
        save_new_trade,
        get_open_trades,
        close_trade,
        get_connection,
        update_trade_freerisk,
        update_trade_dca
    )
    from .config import (
        CAPITAL_PER_TRADE_PERCENT,
        MIN_ORDER_VALUE_IRT,
        TARGET_PROFIT_PERCENT,
        MAKER_FEE_PERCENT,
        DCA_STEP_1_PERCENT,
        DCA_STEP_2_PERCENT,
        STALE_TRADE_TIMEOUT_HOURS,
        ICEBERG_MIN_THRESHOLD_IRT
    )
except ImportError:
    from database import (
        get_paper_balance,
        update_paper_balance,
        save_new_trade,
        get_open_trades,
        close_trade,
        get_connection,
        update_trade_freerisk,
        update_trade_dca
    )
    from config import (
        CAPITAL_PER_TRADE_PERCENT,
        MIN_ORDER_VALUE_IRT,
        TARGET_PROFIT_PERCENT,
        MAKER_FEE_PERCENT,
        DCA_STEP_1_PERCENT,
        DCA_STEP_2_PERCENT,
        STALE_TRADE_TIMEOUT_HOURS,
        ICEBERG_MIN_THRESHOLD_IRT
    )


class PaperTradingEngine:
    def __init__(self):
        pass

    def open_simulated_trade(self, symbol: str, current_price_irt: float, atr: float = 0.0, side: str = "BUY", leverage: float = 1.0) -> Optional[dict]:
        """
        باز کردن یک پوزیشن جدید شبیه‌ساز با قیمت واقعی نوبیتکس
        """
        # بررسی موجودی آزاد کیف پول مجازی
        wallet = get_paper_balance("IRT")
        available = wallet["available"]

        # محاسبه حجم سرمایه ورودی (حداکثر ۱۵ درصد موجودی کل)
        trade_capital = available * (CAPITAL_PER_TRADE_PERCENT / 100.0)

        # اعتبارسنجی حداقل مبلغ نوبیتکس (حداقل ۳۰۰ هزار تومان)
        if trade_capital < MIN_ORDER_VALUE_IRT:
            if available >= MIN_ORDER_VALUE_IRT:
                trade_capital = MIN_ORDER_VALUE_IRT
            else:
                return {"success": False, "error": "موجودی کیف پول شبیه‌ساز برای حداقل سفارش ۳۰۰ هزار تومانی کافی نیست."}

        # محاسبه تعداد ارز بر اساس قیمت
        amount = trade_capital / current_price_irt

        # محاسبه تارگت سود خالص (با کسر کارمزد دوطرفه میکر ۰.۴ درصد)
        # هدف سود ۳ درصدی خالص
        if side in ["BUY", "LONG"]:
            target_price = current_price_irt * (1.0 + ((TARGET_PROFIT_PERCENT + (MAKER_FEE_PERCENT * 2)) / 100.0))
            # حد ضرر بر اساس ۲ برابر ATR یا حداقل ۳.۵ درصد
            stop_distance = max(atr * 2.0, current_price_irt * 0.035) if atr > 0 else (current_price_irt * 0.035)
            stop_loss = current_price_irt - stop_distance
        else: # SHORT
            target_price = current_price_irt * (1.0 - ((TARGET_PROFIT_PERCENT + (MAKER_FEE_PERCENT * 2)) / 100.0))
            stop_distance = max(atr * 2.0, current_price_irt * 0.035) if atr > 0 else (current_price_irt * 0.035)
            stop_loss = current_price_irt + stop_distance

        trade_data = {
            "symbol": symbol,
            "market": "IRT",
            "side": side,
            "mode": "paper",
            "leverage": leverage,
            "entry_price": current_price_irt,
            "amount": amount,
            "total_cost_irt": trade_capital,
            "target_price": target_price,
            "stop_loss": stop_loss,
            "dca_step": 0,
            "notes": f"معامله شبیه‌ساز با ضریب {leverage} | نوع سفارش: {'کوه یخی (حجم بالای ۲ میلیون)' if trade_capital >= ICEBERG_MIN_THRESHOLD_IRT else 'لیمیت عادی'}"
        }

        trade_id = save_new_trade(trade_data)

        # کسر سرمایه از کیف پول شبیه‌ساز
        update_paper_balance("IRT", -trade_capital, 0.0)

        return {
            "success": True,
            "trade_id": trade_id,
            "symbol": symbol,
            "side": side,
            "entry_price": current_price_irt,
            "amount": amount,
            "cost_irt": trade_capital,
            "target_price": target_price,
            "stop_loss": stop_loss
        }

    def update_open_trades(self, live_prices: Dict[str, float]) -> List[dict]:
        """
        پایش لحظه‌ای تمام پوزیشن‌های باز شبیه‌ساز:
        ۱. خروج ۱۰۰ درصدی در تارگت سود خالص ۳ درصد
        ۲. خروج حد ضرر پویا
        ۳. سامانه فری‌ریسک (انتقال استاپ به نقطه ورود در سود بالای ۱.۵٪)
        ۴. خرید پله‌ای (DCA) در اصلاح منفی ۳٪ و منفی ۶٪
        ۵. خروج زمانی از معاملات راکد بعد از ۳.۵ ساعت
        """
        open_trades = get_open_trades()
        events = []
        now_ts = int(time.time())

        for tr in open_trades:
            if tr["mode"] != "paper":
                continue

            symbol = tr["symbol"]
            curr_p = live_prices.get(symbol)
            if not curr_p:
                continue

            trade_id = tr["trade_id"]
            entry_p = tr["entry_price"]
            target_p = tr["target_price"]
            stop_p = tr["stop_loss"]
            side = tr["side"]
            leverage = tr["leverage"]
            cost = tr["total_cost_irt"]
            amount = tr["amount"]
            dca_step = tr.get("dca_step", 0)
            open_ts = tr.get("open_time", now_ts)

            # ۱. محاسبه درصد سود و زیان لحظه‌ای
            if side in ["BUY", "LONG"]:
                pnl_pct = ((curr_p - entry_p) / entry_p) * 100.0 * leverage
                is_hit_target = curr_p >= target_p
                is_hit_stop = curr_p <= stop_p
            else:  # SHORT
                pnl_pct = ((entry_p - curr_p) / entry_p) * 100.0 * leverage
                is_hit_target = curr_p <= target_p
                is_hit_stop = curr_p >= stop_p

            # ۲. بررسی لمس تارگت سود (خروج ۱۰۰ درصدی)
            if is_hit_target:
                res = close_trade(trade_id, curr_p, reason="TARGET_HIT")
                events.append({"event": "CLOSED_PROFIT", "trade": tr, "result": res})
                continue

            # ۳. بررسی لمس حد ضرر
            elif is_hit_stop:
                res = close_trade(trade_id, curr_p, reason="STOP_LOSS")
                events.append({"event": "CLOSED_LOSS", "trade": tr, "result": res})
                continue

            # ۴. سامانه فری‌ریسک پویا (انتقال استاپ به نقطه ورود در سود بالای ۱.۲ درصد)
            if side in ["BUY", "LONG"] and pnl_pct >= 1.2 and stop_p < entry_p:
                update_trade_freerisk(trade_id, entry_p)
                tr["stop_loss"] = entry_p
                events.append({"event": "FREE_RISK_TRIGGERED", "trade": tr, "new_stop": entry_p, "pnl_pct": pnl_pct})

            # ۵. محافظت میانه راه سود (Mid-Way Trailing Guard): خروج ۱۰۰ درصدی در صورت بازگشت قیمت از نزدیکی تارگت
            if side in ["BUY", "LONG"] and pnl_pct >= 2.0:
                if tr.get("peak_reached") and pnl_pct <= 1.4:
                    res = close_trade(trade_id, curr_p, reason="MIDWAY_TRAILING_PROFIT")
                    events.append({"event": "CLOSED_PROFIT", "trade": tr, "result": res})
                    continue
                tr["peak_reached"] = True

            # ۶. خرید پله‌ای هوشمند مشروط (DCA):
            # قانون رفع تناقض: در ریزش‌های آرام فعال است، اما اگر افت بیش از ۵ درصد باشد، سوپاپ ضد سقوط اولویت دارد و خرید پله‌ای قفل می‌شود
            wallet = get_paper_balance("IRT")
            avail_balance = wallet.get("available", 0.0)

            if pnl_pct > -5.0:
                # پله اول DCA در منفی ۳ درصد
                if dca_step == 0 and pnl_pct <= DCA_STEP_1_PERCENT and avail_balance >= MIN_ORDER_VALUE_IRT:
                    step_cost = min(cost, avail_balance)
                    update_paper_balance("IRT", -step_cost, 0.0)
                    new_amount = amount + (step_cost / curr_p)
                    new_cost = cost + step_cost
                    new_entry = new_cost / new_amount
                    new_target = new_entry * (1.0 + ((TARGET_PROFIT_PERCENT + (MAKER_FEE_PERCENT * 2)) / 100.0))
                    new_stop = new_entry * 0.95
                    update_trade_dca(trade_id, new_entry, new_amount, step_cost, new_target, new_stop, 1)
                    tr["entry_price"] = new_entry
                    tr["target_price"] = new_target
                    tr["stop_loss"] = new_stop
                    tr["dca_step"] = 1
                    events.append({"event": "DCA_STEP_BOUGHT", "trade": tr, "step": 1, "added_cost": step_cost, "new_entry": new_entry})

                # پله دوم DCA در منفی ۶ درصد
                elif dca_step == 1 and pnl_pct <= DCA_STEP_2_PERCENT and avail_balance >= MIN_ORDER_VALUE_IRT:
                    step_cost = min(cost * 0.5, avail_balance)
                    update_paper_balance("IRT", -step_cost, 0.0)
                    new_amount = amount + (step_cost / curr_p)
                    new_cost = cost + step_cost
                    new_entry = new_cost / new_amount
                    new_target = new_entry * (1.0 + ((TARGET_PROFIT_PERCENT + (MAKER_FEE_PERCENT * 2)) / 100.0))
                    new_stop = new_entry * 0.94
                    update_trade_dca(trade_id, new_entry, new_amount, step_cost, new_target, new_stop, 2)
                    tr["entry_price"] = new_entry
                    tr["target_price"] = new_target
                    tr["stop_loss"] = new_stop
                    tr["dca_step"] = 2
                    events.append({"event": "DCA_STEP_BOUGHT", "trade": tr, "step": 2, "added_cost": step_cost, "new_entry": new_entry})

            # ۷. خروج زمانی خودکار از معاملات راکد بعد از ۳.۵ ساعت
            duration_hours = (now_ts - open_ts) / 3600.0
            if duration_hours >= STALE_TRADE_TIMEOUT_HOURS and abs(pnl_pct) <= 0.8:
                res = close_trade(trade_id, curr_p, reason="STALE_TIMEOUT")
                events.append({"event": "CLOSED_STALE", "trade": tr, "result": res, "duration_hours": duration_hours})
                continue

            # ۸. بستن مشروط قبل از کارمزد شبانه نوبیتکس (۲۳:۴۵ تا ۲۳:۵۹) صرفاً برای سودهای ناچیز (زیر ۱ درصد)
            curr_struct = time.localtime(now_ts)
            if curr_struct.tm_hour == 23 and curr_struct.tm_min >= 45:
                if leverage > 1.0 and abs(pnl_pct) < 1.0:
                    res = close_trade(trade_id, curr_p, reason="PRE_ROLLOVER_EXIT")
                    events.append({"event": "CLOSED_STALE", "trade": tr, "result": res, "duration_hours": duration_hours})
                    continue

        return events
