# -*- coding: utf-8 -*-
"""
ماژول اختصاصی ارتباط با وب‌سرویس و وب‌سوکت صرافی نوبیتکس
شامل دریافت قیمت‌های بلادرنگ، عمق اردربوک، کندل‌های تاریخی و تحلیل اسپرد بازارهای تومانی و تتری
"""

import urllib.request
import urllib.parse
import json
import time
from typing import Dict, List, Optional, Any
try:
    from .config import (
        NOBITEX_MARKET_STATS,
        NOBITEX_ORDERBOOK,
        NOBITEX_CANDLES,
        NOBITEX_WALLETS,
        NOBITEX_ADD_ORDER,
        NOBITEX_ORDER_STATUS,
        NOBITEX_CANCEL_ORDER
    )
except ImportError:
    from config import (
        NOBITEX_MARKET_STATS,
        NOBITEX_ORDERBOOK,
        NOBITEX_CANDLES,
        NOBITEX_WALLETS,
        NOBITEX_ADD_ORDER,
        NOBITEX_ORDER_STATUS,
        NOBITEX_CANCEL_ORDER
    )


class NobitexClient:
    def __init__(self, api_token: str = ""):
        self.api_token = api_token
        self.opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        self.user_agent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"

    def _request(self, url: str, method: str = "GET", data: Optional[dict] = None, timeout: int = 8) -> Optional[dict]:
        """ارسال ایمن درخواست اچ‌تی‌تی‌پی به وب‌سرویس نوبیتکس"""
        headers = {
            "User-Agent": self.user_agent,
            "Accept": "application/json"
        }
        if self.api_token:
            headers["Authorization"] = f"Token {self.api_token}"

        encoded_data = None
        if data:
            headers["Content-Type"] = "application/json"
            encoded_data = json.dumps(data).encode("utf-8")

        try:
            req = urllib.request.Request(url, data=encoded_data, headers=headers, method=method)
            with self.opener.open(req, timeout=timeout) as resp:
                raw_body = resp.read().decode("utf-8")
                return json.loads(raw_body)
        except Exception as e:
            # در صورت قطعی یا خطا در ارتباط با نوبیتکس
            return None

    def get_market_stats(self, src_currency: str = "", dst_currency: str = "") -> Optional[dict]:
        """دریافت آخرین آمار ۲۴ ساعته تمام جفت‌ارزها، آخرین قیمت‌ها و حجم معاملات"""
        url = NOBITEX_MARKET_STATS
        params = {}
        if src_currency:
            params["srcCurrency"] = src_currency
        if dst_currency:
            params["dstCurrency"] = dst_currency
        if params:
            url = f"{url}?{urllib.parse.urlencode(params)}"
            
        res = self._request(url)
        if res and res.get("status") == "ok":
            return res.get("stats", {})
        return None

    def get_orderbook(self, symbol: str) -> Optional[dict]:
        """
        دریافت عمق دفتر سفارشات (اردربوک) یک ارز
        نمونه symbol: btc-rls یا btc-usdt
        """
        url = f"{NOBITEX_ORDERBOOK}/{symbol}"
        res = self._request(url)
        if res and res.get("status") == "ok":
            return {
                "bids": res.get("bids", []),  # خریداران [[قیمت, حجم], ...]
                "asks": res.get("asks", []),  # فروشندگان [[قیمت, حجم], ...]
                "last_update": res.get("lastUpdate")
            }
        return None

    def get_candles(self, symbol: str, resolution: str = "15", count_back: int = 60) -> Optional[dict]:
        """
        دریافت کندل‌های قیمتی برای تحلیل اندیکاتورها (UDF History)
        نمونه resolution: 15 (تایم فریم ۱۵ دقیقه), 60 (۱ ساعته), D (روزانه)
        """
        now_ts = int(time.time())
        # محاسبه زمان شروع بر اساس تعداد کندل و تایم‌فریم
        multiplier = 15 * 60 if resolution == "15" else (60 * 60 if resolution == "60" else 86400)
        from_ts = now_ts - (count_back * multiplier)
        
        params = {
            "symbol": symbol,
            "resolution": resolution,
            "from": from_ts,
            "to": now_ts
        }
        url = f"{NOBITEX_CANDLES}?{urllib.parse.urlencode(params)}"
        res = self._request(url)
        if res and res.get("s") == "ok":
            return {
                "time": res.get("t", []),
                "open": res.get("o", []),
                "high": res.get("h", []),
                "low": res.get("l", []),
                "close": res.get("c", []),
                "volume": res.get("v", [])
            }
        return None

    def calculate_spread_percentage(self, orderbook: dict) -> float:
        """محاسبه درصد اختلاف بین بهترین قیمت خرید و بهترین قیمت فروش (Bid-Ask Spread)"""
        bids = orderbook.get("bids", [])
        asks = orderbook.get("asks", [])
        if not bids or not asks:
            return 999.0
            
        best_bid = float(bids[0][0])
        best_ask = float(asks[0][0])
        if best_bid <= 0:
            return 999.0
            
        spread = ((best_ask - best_bid) / best_bid) * 100.0
        return round(spread, 3)

    def find_resistance_walls(self, orderbook: dict, threshold_ratio: float = 3.0) -> List[dict]:
        """
        شناسایی دیوارهای سنگین فروش در اردربوک (Resistance Wall Front-Running)
        تشخیص حجم‌های غیرعادی که ۳ برابر میانگین ردیف‌های اردربوک هستند
        """
        asks = orderbook.get("asks", [])
        if len(asks) < 5:
            return []
            
        volumes = [float(item[1]) for item in asks[:15]]
        avg_vol = sum(volumes) / len(volumes) if volumes else 1.0
        
        walls = []
        for price_str, vol_str in asks[:15]:
            p = float(price_str)
            v = float(vol_str)
            if v >= (avg_vol * threshold_ratio):
                walls.append({"price": p, "volume": v, "is_wall": True})
                
        return walls
