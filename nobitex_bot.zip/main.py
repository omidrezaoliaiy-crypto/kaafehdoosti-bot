# -*- coding: utf-8 -*-
"""
فایل اصلی اجرای ربات معامله‌گر هوشمند نوبیتکس
همگام‌سازی اسکنر ۲۴ ساعته بازار، موتور شبیه‌ساز و ربات تلگرام
"""

import time
import threading
import os
import sys

# تنظیم مسیر پروژه
PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from config import TELEGRAM_BOT_TOKEN
from database import init_db, get_setting
from nobitex_client import NobitexClient
from market_scanner import MarketScanner
from telegram_bot import TelegramBot


def background_market_scanner(tg_bot: TelegramBot):
    """حلقه ۲۴ ساعته اسکن بازار نوبیتکس و ارسال بلادرنگ هشدارها به تلگرام"""
    scanner = MarketScanner()
    print("اسکنر خودکار بازار نوبیتکس در پس‌زمینه شروع به کار کرد...", flush=True)

    while True:
        try:
            events = scanner.run_scan_cycle()
            admin_id = get_setting("telegram_admin_id")

            if events and admin_id:
                chat_id = int(admin_id)
                for ev in events:
                    ev_type = ev.get("event")

                    if ev_type == "OPENED_TRADE":
                        res = ev.get("result", {})
                        sig = ev.get("signal", {})
                        msg = (
                            f"[معامله شبیه‌ساز - خرید جدید]\n\n"
                            f"ارز خریداری شده: {res.get('symbol')}\n"
                            f"قیمت ورود: {res.get('entry_price', 0):,.0f} تومان\n"
                            f"تارگت خروج ۱۰۰ درصدی: {res.get('target_price', 0):,.0f} تومان (+۳.۴٪)\n"
                            f"حد ضرر پویا (ATR): {res.get('stop_loss', 0):,.0f} تومان\n"
                            f"حجم کل معامله: {res.get('cost_irt', 0):,.0f} تومان\n"
                            f"دلیل ورود: {sig.get('reason', 'تاییدیه اندیکاتورها')}"
                        )
                        tg_bot.send_message(chat_id, msg)

                    elif ev_type == "CLOSED_PROFIT":
                        res = ev.get("result", {})
                        tr = ev.get("trade", {})
                        msg = (
                            f"[معامله شبیه‌ساز - سود ذخیره شد! 🎉]\n\n"
                            f"ارز: {tr.get('symbol')}\n"
                            f"میزان سود کسب‌شده: {res.get('pnl_irt', 0):,.0f} تومان (+{res.get('pnl_percent', 0):.2f}%)\n"
                            f"دلیل خروج: لمس کامل تارگت خروج ۱۰۰ درصدی\n"
                            f"سرمایه به همراه سود به کیف پول مجازی بازگشت."
                        )
                        tg_bot.send_message(chat_id, msg)

                    elif ev_type == "CLOSED_LOSS":
                        res = ev.get("result", {})
                        tr = ev.get("trade", {})
                        msg = (
                            f"[معامله شبیه‌ساز - خروج با حد ضرر]\n\n"
                            f"ارز: {tr.get('symbol')}\n"
                            f"زیان کنترل‌شده: {abs(res.get('pnl_irt', 0)):,.0f} تومان ({res.get('pnl_percent', 0):.2f}%)\n"
                            f"دلیل خروج: فعال‌سازی حد ضرر پویا جهت محافظت از کل سرمایه"
                        )
                        tg_bot.send_message(chat_id, msg)

                    elif ev_type == "FREE_RISK_TRIGGERED":
                        tr = ev.get("trade", {})
                        msg = (
                            f"[معامله شبیه‌ساز - سپر فری‌ریسک فعال شد! 🛡️]\n\n"
                            f"ارز: {tr.get('symbol')}\n"
                            f"سود لحظه‌ای: +{ev.get('pnl_pct', 0):.2f}%\n"
                            f"حد ضرر به نقطه ورود منتقل شد. از این لحظه ریسک این معامله صفر شد."
                        )
                        tg_bot.send_message(chat_id, msg)

                    elif ev_type == "DCA_STEP_BOUGHT":
                        tr = ev.get("trade", {})
                        step_num = ev.get("step", 1)
                        msg = (
                            f"[معامله شبیه‌ساز - خرید پله‌ای هوشمند DCA]\n\n"
                            f"ارز: {tr.get('symbol')} (مرحله {step_num})\n"
                            f"حجم پله جدید: {ev.get('added_cost', 0):,.0f} تومان\n"
                            f"میانگین جدید قیمت ورود: {ev.get('new_entry', 0):,.0f} تومان\n"
                            f"تارگت جدید سود: {tr.get('target_price', 0):,.0f} تومان"
                        )
                        tg_bot.send_message(chat_id, msg)

                    elif ev_type == "CLOSED_STALE":
                        res = ev.get("result", {})
                        tr = ev.get("trade", {})
                        dur = ev.get("duration_hours", 3.5)
                        msg = (
                            f"[معامله شبیه‌ساز - خروج زمانی از معامله راکد]\n\n"
                            f"ارز: {tr.get('symbol')}\n"
                            f"مدت معامله: {dur:.1f} ساعت بدون نوسان کافی\n"
                            f"سرمایه آزاد شد تا برای شکار موقعیت‌های آماده رشد جدید مصرف شود."
                        )
                        tg_bot.send_message(chat_id, msg)

        except Exception as e:
            print(f"خطای حلقه اسکنر: {e}", flush=True)

        # اسکن هر ۴۵ ثانیه یک‌بار
        time.sleep(45)


def main():
    print("=" * 60)
    print("در حال راه‌اندازی ربات معامله‌گر هوشمند نوبیتکس...")
    print("=" * 60)

    # ۱. راه‌اندازی پایگاه داده
    init_db()
    print("پایگاه داده اس‌کیولایت با موفقیت بارگذاری شد.")

    # ۲. راه‌اندازی ربات تلگرام
    tg_bot = TelegramBot(token=TELEGRAM_BOT_TOKEN)

    # ۳. راه‌اندازی حلقه اسکنر پس‌زمینه در ترد مستقل
    scanner_thread = threading.Thread(target=background_market_scanner, args=(tg_bot,), daemon=True)
    scanner_thread.start()

    # ۴. اجرای حلقه دریافت پیام‌های تلگرام
    print("ربات تلگرام آماده دریافت دستورات است. (ارسال /start در تلگرام)")
    tg_bot.run_polling()


if __name__ == "__main__":
    main()
