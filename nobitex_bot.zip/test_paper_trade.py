import sys
import os

sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from paper_trading import PaperTradingEngine
from nobitex_client import NobitexClient
import database

print("موجودی قبل از معامله:", database.get_paper_balance("IRT"))

client = NobitexClient()
stats = client.get_market_stats()
btc = stats.get("btc-rls", {})
btc_price_irt = float(btc.get("latest", 0)) / 10.0

engine = PaperTradingEngine()
res = engine.open_simulated_trade("BTCIRT", btc_price_irt, atr=50000000, side="BUY", leverage=1.0)
print("\nنتیجه باز کردن معامله شبیه‌ساز:")
print(res)

print("\nموجودی بعد از معامله (تومان باقی‌مانده):", database.get_paper_balance("IRT"))
print("\nلیست معاملات باز در دیتابیس:")
for tr in database.get_open_trades():
    print(f"کد: {tr['trade_id']} | نماد: {tr['symbol']} | قیمت ورود: {tr['entry_price']:,.0f} | تارگت خروج: {tr['target_price']:,.0f} | حد ضرر: {tr['stop_loss']:,.0f}")
