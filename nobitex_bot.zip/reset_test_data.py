import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
import database

conn = database.get_connection()
c = conn.cursor()
c.execute("DELETE FROM trades")
c.execute("UPDATE paper_wallet SET balance = 10000000.0, locked = 0.0 WHERE asset = 'IRT'")
conn.commit()
conn.close()
print("Cleaned up test trades, balance reset to 10,000,000 Tomans.")
