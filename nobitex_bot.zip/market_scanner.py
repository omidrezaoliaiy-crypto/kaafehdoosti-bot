# -*- coding: utf-8 -*-
"""
اسکنر ۲۴ ساعته و موتور تحلیل بازار نوبیتکس
پایش نقدشوندگی، فیلتر روند بیت‌کوین و تولید سیگنال‌های هوشمند ورود
"""

import time
from typing import List, Dict, Optional
try:
    from .nobitex_client import NobitexClient
    from .indicators import calculate_rsi, calculate_ema, calculate_atr, detect_bullish_divergence
    from .paper_trading import PaperTradingEngine
    from .database import get_trading_mode, is_margin_enabled, get_margin_max_multiplier
    from .config import CIRCUIT_BREAKER_DROP_PERCENT
except ImportError:
    from nobitex_client import NobitexClient
    from indicators import calculate_rsi, calculate_ema, calculate_atr, detect_bullish_divergence
    from paper_trading import PaperTradingEngine
    from database import get_trading_mode, is_margin_enabled, get_margin_max_multiplier
    from config import CIRCUIT_BREAKER_DROP_PERCENT


# لیست جفت‌ارزهای پرنقدشونده و برتر بازار تومانی نوبیتکس
TARGET_MARKETS_IRT = [
    "BTCIRT",
    "ETHIRT",
    "USDTIRT",
    "SOLIRT",
    "TONIRT",
    "DOGEIRT",
    "XRPIRT",
    "TRXIRT",
    "ADAIRT",
    "SHIBIRT"
]

# لیست جفت‌ارزهای پرنقدشونده بازار تتری نوبیتکس
TARGET_MARKETS_USDT = [
    "BTCUSDT",
    "ETHUSDT",
    "SOLUSDT",
    "TONUSDT",
    "DOGEUSDT",
    "XRPUSDT",
    "TRXUSDT",
    "ADAUSDT"
]


class MarketScanner:
    def __init__(self, client: Optional[NobitexClient] = None):
        self.client = client or NobitexClient()
        self.paper_engine = PaperTradingEngine()
        self.last_btc_price: float = 0.0
        self.last_btc_check_time: float = 0.0

    def check_bitcoin_filter(self, stats: dict) -> tuple:
        """
        فیلتر روند بیت‌کوین (قابلیت ۱ و ۱۵):
        بررسی ریزش شارپ بیت‌کوین؛ در صورت افت شدید، ورود به آلت‌کوین‌ها قفل می‌شود
        """
        btc = stats.get("btc-rls")
        if not btc:
            return True, "داده‌های بیت‌کوین در دسترس نیست."

        current_btc_irt = float(btc.get("latest", 0)) / 10.0
        now_ts = time.time()

        if self.last_btc_price > 0 and (now_ts - self.last_btc_check_time) <= 120:
            pct_change = ((current_btc_irt - self.last_btc_price) / self.last_btc_price) * 100.0
            # اگر در ۲ دقیقه گذشته بیش از ۱.۵ درصد افت کرده باشد (ریزش شارپ)
            if pct_change <= -1.5:
                return False, f"هشدار ریزش شارپ بیت‌کوین ({pct_change:.1f} درصد). خریدهای جدید موقتاً قفل شدند."

        self.last_btc_price = current_btc_irt
        self.last_btc_check_time = now_ts
        return True, "روند بیت‌کوین پایدار است."

    def scan_market_pair(self, symbol: str) -> Optional[dict]:
        """
        تحلیل تکنیکال یک نماد با دو الگوی ورود مستقل (رفع تناقض شده):
        الگوی ۱: اشباع فروش سنگین (RSI < 30)
        الگوی ۲: واگرایی مثبت مخفی یا معمولی (RSI بین ۳۵ تا ۵۵)
        """
        candles = self.client.get_candles(symbol, resolution="15", count_back=35)
        if not candles or not candles.get("close") or len(candles["close"]) < 25:
            return None

        closes = [float(c) for c in candles["close"]]
        highs = [float(h) for h in candles["high"]]
        lows = [float(l) for l in candles["low"]]

        current_price = closes[-1]

        # ۱. محاسبه RSI
        rsi_list = calculate_rsi(closes, period=14)
        if not rsi_list:
            return None
        current_rsi = rsi_list[-1]

        # ۲. محاسبه EMA 21
        ema21_list = calculate_ema(closes, period=21)
        ema21 = ema21_list[-1] if ema21_list else current_price

        # ۳. محاسبه ATR برای حد ضرر پویا
        atr_list = calculate_atr(highs, lows, closes, period=14)
        atr = atr_list[-1] if atr_list else (current_price * 0.02)

        # ۴. بررسی واگرایی مثبت
        has_divergence, div_type = detect_bullish_divergence(closes, rsi_list)

        signal = None

        # شرط ورود الگوی ۱: اشباع فروش شدید (RSI زیر ۳۰ + قیمت بالاتر از کف کندل قبلی)
        if current_rsi < 30.0:
            signal = {
                "symbol": symbol,
                "pattern": "OVERSOLD_BOUNCE",
                "price": current_price,
                "rsi": current_rsi,
                "atr": atr,
                "reason": f"اشباع فروش شدید (RSI={current_rsi:.1f})"
            }

        # شرط ورود الگوی ۲: واگرایی مثبت (آر اس آی نرمال و تایید واگرایی)
        elif has_divergence and (35.0 <= current_rsi <= 55.0):
            signal = {
                "symbol": symbol,
                "pattern": div_type,
                "price": current_price,
                "rsi": current_rsi,
                "atr": atr,
                "reason": f"شکار واگرایی مثبت ({div_type}) با RSI={current_rsi:.1f}"
            }

        return signal

    def run_scan_cycle(self) -> List[dict]:
        """اجرای یک دور کامل اسکن بازار، فیلترها و پایش معاملات باز"""
        stats = self.client.get_market_stats()
        if not stats:
            return []

        # ۱. استخراج قیمت‌های زنده تومانی برای به‌روزرسانی پوزیشن‌های باز
        live_prices = {}
        for k, v in stats.items():
            sym = k.replace("-rls", "IRT").upper()
            try:
                live_prices[sym] = float(v.get("latest", 0)) / 10.0
            except Exception:
                pass

        # ۲. پایش معاملات باز و بررسی تارگت و استاپ
        closed_events = self.paper_engine.update_open_trades(live_prices)

        # بررسی وضعیت کلید شروع / توقف معاملات
        from database import get_setting, check_daily_drawdown, get_open_trades
        if get_setting("trading_active", "1") == "0":
            return closed_events

        # بررسی سقف ضرر مجاز روزانه (۲.۵ درصد) جهت توقف خودکار معاملات
        dd_ok, dd_loss = check_daily_drawdown(max_drawdown_pct=2.5)
        if not dd_ok:
            return closed_events

        # کنترل سقف معاملات همزمان (حداکثر ۳ پوزیشن برای مدیریت سرمایه ۴۵ درصدی)
        current_open = get_open_trades()
        if len(current_open) >= 3:
            return closed_events

        # ۳. بررسی فیلتر بیت‌کوین قبل از جستجوی خریدهای جدید
        btc_ok, btc_msg = self.check_bitcoin_filter(stats)
        if not btc_ok:
            return closed_events

        # ۴. تعیین لیست ارزهای هدف بر اساس تنظیم نوع بازار (تومانی / تتری / هر دو)
        market_type_setting = get_setting("market_type", "تومانی")
        if "فقط بازار تتری" in market_type_setting:
            target_list = TARGET_MARKETS_USDT
        elif "هر دو بازار" in market_type_setting:
            target_list = TARGET_MARKETS_IRT + TARGET_MARKETS_USDT
        else:
            target_list = TARGET_MARKETS_IRT

        # نمادهایی که هم‌اکنون در آنها معامله باز داریم را از ورود مجدد مستثنی می‌کنیم
        open_symbols = {t["symbol"] for t in current_open}

        for symbol in target_list:
            if symbol in open_symbols:
                continue

            try:
                sig = self.scan_market_pair(symbol)
                if sig:
                    # تعیین اهرم معامله در صورت فعال بودن بخش اهرم
                    margin_active = is_margin_enabled()
                    leverage_val = get_margin_max_multiplier() if margin_active else 1.0

                    # اجرای خرید در شبیه‌ساز
                    res = self.paper_engine.open_simulated_trade(
                        symbol=sig["symbol"],
                        current_price_irt=sig["price"],
                        atr=sig["atr"],
                        side="BUY",
                        leverage=leverage_val
                    )
                    if res.get("success"):
                        closed_events.append({"event": "OPENED_TRADE", "signal": sig, "result": res})
                        open_symbols.add(symbol)
            except Exception:
                pass

        return closed_events
