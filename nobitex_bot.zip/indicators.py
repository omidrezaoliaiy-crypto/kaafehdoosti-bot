# -*- coding: utf-8 -*-
"""
محاسبات ریاضی و فرمول‌های تکنیکال اندیکاتورها (RSI, EMA, ATR, Divergence)
طراحی شده به صورت کاملاً مستقل و سبک با پایتون خالص
"""

from typing import List, Dict, Tuple, Optional


def calculate_ema(prices: List[float], period: int) -> List[float]:
    """محاسبه میانگین متحرک نمایی (EMA)"""
    if len(prices) < period:
        return []
    
    multiplier = 2.0 / (period + 1)
    ema_list = []
    
    # مقدار اولیه میانگین ساده است
    sma = sum(prices[:period]) / period
    ema_list.append(sma)
    
    for p in prices[period:]:
        new_ema = (p - ema_list[-1]) * multiplier + ema_list[-1]
        ema_list.append(new_ema)
        
    return ema_list


def calculate_rsi(prices: List[float], period: int = 14) -> List[float]:
    """محاسبه شاخص قدرت نسبی (RSI) به روش ویلدرز"""
    if len(prices) <= period:
        return []
        
    gains = []
    losses = []
    
    for i in range(1, len(prices)):
        delta = prices[i] - prices[i - 1]
        if delta >= 0:
            gains.append(delta)
            losses.append(0.0)
        else:
            gains.append(0.0)
            losses.append(abs(delta))
            
    if len(gains) < period:
        return []
        
    avg_gain = sum(gains[:period]) / period
    avg_loss = sum(losses[:period]) / period
    
    rsi_list = []
    if avg_loss == 0:
        rsi_list.append(100.0)
    else:
        rs = avg_gain / avg_loss
        rsi_list.append(100.0 - (100.0 / (1.0 + rs)))
        
    for i in range(period, len(gains)):
        avg_gain = (avg_gain * (period - 1) + gains[i]) / period
        avg_loss = (avg_loss * (period - 1) + losses[i]) / period
        
        if avg_loss == 0:
            rsi_list.append(100.0)
        else:
            rs = avg_gain / avg_loss
            rsi_list.append(100.0 - (100.0 / (1.0 + rs)))
            
    return rsi_list


def calculate_atr(highs: List[float], lows: List[float], closes: List[float], period: int = 14) -> List[float]:
    """محاسبه دامنه واقعی میانگین (ATR) برای حد ضرر و فری‌ریسک پویا"""
    if len(closes) <= period or len(highs) != len(closes) or len(lows) != len(closes):
        return []
        
    tr_list = []
    for i in range(1, len(closes)):
        h = highs[i]
        l = lows[i]
        prev_c = closes[i - 1]
        tr = max(h - l, abs(h - prev_c), abs(l - prev_c))
        tr_list.append(tr)
        
    if len(tr_list) < period:
        return []
        
    atr_list = []
    first_atr = sum(tr_list[:period]) / period
    atr_list.append(first_atr)
    
    for tr in tr_list[period:]:
        new_atr = (atr_list[-1] * (period - 1) + tr) / period
        atr_list.append(new_atr)
        
    return atr_list


def detect_bullish_divergence(prices: List[float], rsi_values: List[float], window: int = 5) -> Tuple[bool, str]:
    """
    تشخیص واگرایی مثبت معمولی (Regular Bullish) و مخفی (Hidden Bullish)
    برای شکار نقاط چرخش صعودی با ضریب برد بالا
    """
    if len(prices) < 20 or len(rsi_values) < 20:
        return False, "NONE"
        
    # بررسی کف‌های قیمتی اخیر
    p2 = prices[-1]           # کف قیمت فعلی
    p1 = min(prices[-15:-5])  # کف قیمت قبلی
    
    rsi2 = rsi_values[-1]     # مقدار آر اس آی فعلی
    rsi1 = min(rsi_values[-15:-5]) # مقدار آر اس آی قبلی
    
    # واگرایی مثبت معمولی: قیمت کف پایین‌تر ساخته اما آر اس آی کف بالاتر ساخته (چرخش از روند نزولی)
    if p2 < p1 and rsi2 > rsi1 and rsi2 < 45:
        return True, "REGULAR_BULLISH"
        
    # واگرایی مثبت مخفی: قیمت کف بالاتر ساخته اما آر اس آی کف پایین‌تر ساخته (ادامه روند صعودی در پولبک)
    if p2 > p1 and rsi2 < rsi1 and (35 <= rsi2 <= 55):
        return True, "HIDDEN_BULLISH"
        
    return False, "NONE"
