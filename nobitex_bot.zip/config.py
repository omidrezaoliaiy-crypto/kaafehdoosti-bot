# -*- coding: utf-8 -*-
"""
تنظیمات جامع و پارامترهای ریسک ربات معامله‌گر هوشمند نوبیتکس
"""

import os

# مسیرهای پایگاه داده و فایل‌ها
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "nobitex_bot.db")

# آدرس‌های وب‌سرویس رسمی نوبیتکس
NOBITEX_BASE_URL = "https://apiv2.nobitex.ir"
NOBITEX_MARKET_STATS = f"{NOBITEX_BASE_URL}/market/stats"
NOBITEX_ORDERBOOK = f"{NOBITEX_BASE_URL}/v2/orderbook"
NOBITEX_CANDLES = f"{NOBITEX_BASE_URL}/market/udf/history"
NOBITEX_WALLETS = f"{NOBITEX_BASE_URL}/users/wallets/list"
NOBITEX_ADD_ORDER = f"{NOBITEX_BASE_URL}/market/orders/add"
NOBITEX_ORDER_STATUS = f"{NOBITEX_BASE_URL}/market/orders/status"
NOBITEX_CANCEL_ORDER = f"{NOBITEX_BASE_URL}/market/orders/cancel"

# توکن ربات اختصاصی تلگرام نوبیتکس
TELEGRAM_BOT_TOKEN = "9198797379:AAGB8dg5nOpfOGvJ_p2nNT3cdH-Zvyq-8AQ"

# حالت‌های کاری ربات
MODE_PAPER = "paper"  # حالت شبیه‌ساز و تمرینی بدون درگیری پول واقعی
MODE_REAL = "real"    # حالت واقعی متصل به صرافی

# موجودی اولیه پیش‌فرض کیف پول شبیه‌ساز (تومان)
DEFAULT_PAPER_BALANCE_IRT = 10000000  # ۱۰ میلیون تومان

# پارامترهای مدیریت ریسک و سرمایه (بخش اول و دوم)
CAPITAL_PER_TRADE_PERCENT = 15.0       # حداکثر ۱۵ درصد کل سرمایه در هر پوزیشن
MAX_DAILY_DRAWDOWN_PERCENT = 2.5       # سقف ضرر روزانه؛ توقف ۲۴ ساعته در صورت لمس
CIRCUIT_BREAKER_DROP_PERCENT = 5.0     # سوپاپ ضد سقوط: افت بیش از ۵ درصد در ۱ دقیقه
MIN_ORDER_VALUE_IRT = 300000          # حداقل مبلغ قانونی سفارش در نوبیتکس (۳۰۰ هزار تومان)
ICEBERG_MIN_THRESHOLD_IRT = 2000000   # حداقل حجم برای فعال‌سازی سفارش کوه یخی (۲ میلیون تومان)
MAKER_FEE_PERCENT = 0.2               # کارمزد سازنده (میکر)
TAKER_FEE_PERCENT = 0.35              # کارمزد گیرنده (تیکر)
AUTO_CHASE_TIMEOUT_SECONDS = 45       # تایمر لغو و اصلاح سفارش لیمیت
STALE_TRADE_TIMEOUT_HOURS = 3.5       # خروج زمانی از معاملات راکد بعد از ۳.۵ ساعت

# پارامترهای خرید پله‌ای و حد سود
DCA_STEP_1_PERCENT = -3.0              # پله دوم خرید در منفی ۳ درصد
DCA_STEP_2_PERCENT = -6.0              # پله سوم خرید در منفی ۶ درصد
TARGET_PROFIT_PERCENT = 3.0           # تارگت سود خالص خروج ۱۰۰ درصدی

# پارامترهای معاملات تعهدی و اهرم (بخش سوم)
MARGIN_DEFAULT_ENABLED = False        # پیش‌فرض اهرم خاموش (فقط اسپات)
MARGIN_MAX_MULTIPLIER = 2.0           # سقف ضریب اهرم مجاز (۱.۵، ۲، ۳، ۵)
MARGIN_MAX_PORTFOLIO_PERCENT = 30.0   # سقف کل مارجین درگیر در کل حساب (حداکثر ۳۰ درصد)
MARGIN_MAX_CONCURRENT_TRADES = 1      # سقف معاملات اهرمی همزمان (دقیقاً ۱ پوزیشن)
LIQUIDATION_BUFFER_PERCENT = 70.0     # حداقل فاصله امن از قیمت لیکوییدی
