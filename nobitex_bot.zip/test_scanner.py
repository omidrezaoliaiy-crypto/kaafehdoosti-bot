import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from market_scanner import MarketScanner

scanner = MarketScanner()
print("شروع اسکن زنده بازار نوبیتکس...")
events = scanner.run_scan_cycle()
print(f"اسکن با موفقیت تکمیل شد. تعداد رویدادهای معاملاتی: {len(events)}")
for ev in events:
    print("رویداد:", ev.get("event"))
