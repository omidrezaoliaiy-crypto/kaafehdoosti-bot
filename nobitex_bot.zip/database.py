# -*- coding: utf-8 -*-
"""
ماژول پایگاه داده محلی SQLite برای ذخیره تنظیمات، پوزیشن‌های معاملاتی و تاریخچه سود ربات نوبیتکس
"""

import sqlite3
import os
import time
try:
    from .config import DB_PATH, MODE_PAPER, DEFAULT_PAPER_BALANCE_IRT, MARGIN_DEFAULT_ENABLED, MARGIN_MAX_MULTIPLIER
except ImportError:
    from config import DB_PATH, MODE_PAPER, DEFAULT_PAPER_BALANCE_IRT, MARGIN_DEFAULT_ENABLED, MARGIN_MAX_MULTIPLIER


def get_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_connection()
    c = conn.cursor()

    # جدول تنظیمات عمومی و پیکربندی ربات
    c.execute("""
    CREATE TABLE IF NOT EXISTS settings (
        key TEXT PRIMARY KEY,
        value TEXT
    )
    """)

    # جدول کیف پول مجازی (حالت شبیه‌ساز)
    c.execute("""
    CREATE TABLE IF NOT EXISTS paper_wallet (
        asset TEXT PRIMARY KEY,
        balance REAL,
        locked REAL
    )
    """)

    # جدول معاملات (اسپات و تعهدی)
    c.execute("""
    CREATE TABLE IF NOT EXISTS trades (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        trade_id TEXT UNIQUE,
        symbol TEXT,
        market TEXT,
        side TEXT,
        mode TEXT,
        leverage REAL DEFAULT 1.0,
        entry_price REAL,
        amount REAL,
        total_cost_irt REAL,
        current_price REAL,
        target_price REAL,
        stop_loss REAL,
        trailing_stop REAL,
        break_even_active INTEGER DEFAULT 0,
        dca_step INTEGER DEFAULT 0,
        status TEXT DEFAULT 'OPEN',
        pnl_irt REAL DEFAULT 0.0,
        pnl_percent REAL DEFAULT 0.0,
        open_time INTEGER,
        close_time INTEGER DEFAULT 0,
        close_reason TEXT DEFAULT '',
        notes TEXT DEFAULT ''
    )
    """)

    # جدول آمار روزانه برای پایش سقف ضرر روزانه (Max Daily Drawdown)
    c.execute("""
    CREATE TABLE IF NOT EXISTS daily_stats (
        date_str TEXT PRIMARY KEY,
        total_trades INTEGER DEFAULT 0,
        winning_trades INTEGER DEFAULT 0,
        losing_trades INTEGER DEFAULT 0,
        total_pnl_irt REAL DEFAULT 0.0,
        total_pnl_percent REAL DEFAULT 0.0,
        circuit_tripped INTEGER DEFAULT 0
    )
    """)

    conn.commit()

    # مقداردهی اولیه تنظیمات پیش‌فرض در صورت عدم وجود
    default_settings = {
        "trading_mode": MODE_PAPER,
        "margin_enabled": "1" if MARGIN_DEFAULT_ENABLED else "0",
        "margin_max_multiplier": str(MARGIN_MAX_MULTIPLIER),
        "bot_active": "1",
        "nobitex_token": "",
        "telegram_admin_id": "",
    }
    for k, v in default_settings.items():
        c.execute("INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)", (k, v))

    # مقداردهی اولیه کیف پول مجازی با ۱۰ میلیون تومان
    c.execute("INSERT OR IGNORE INTO paper_wallet (asset, balance, locked) VALUES ('IRT', ?, 0.0)", (float(DEFAULT_PAPER_BALANCE_IRT),))
    c.execute("INSERT OR IGNORE INTO paper_wallet (asset, balance, locked) VALUES ('USDT', 0.0, 0.0)")

    conn.commit()
    conn.close()


def get_setting(key, default=""):
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT value FROM settings WHERE key = ?", (key,))
    row = c.fetchone()
    conn.close()
    return row["value"] if row else default


def set_setting(key, value):
    conn = get_connection()
    c = conn.cursor()
    c.execute("INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)", (key, str(value)))
    conn.commit()
    conn.close()


def get_trading_mode():
    return get_setting("trading_mode", MODE_PAPER)


def set_trading_mode(mode):
    set_setting("trading_mode", mode)


def is_margin_enabled():
    return get_setting("margin_enabled", "0") == "1"


def set_margin_enabled(enabled: bool):
    set_setting("margin_enabled", "1" if enabled else "0")


def get_margin_max_multiplier():
    return float(get_setting("margin_max_multiplier", str(MARGIN_MAX_MULTIPLIER)))


def set_margin_max_multiplier(mult: float):
    set_setting("margin_max_multiplier", str(mult))


# --- مدیریت کیف پول شبیه‌ساز ---
def get_paper_balance(asset="IRT"):
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT balance, locked FROM paper_wallet WHERE asset = ?", (asset,))
    row = c.fetchone()
    conn.close()
    if row:
        return {"balance": row["balance"], "locked": row["locked"], "available": row["balance"] - row["locked"]}
    return {"balance": 0.0, "locked": 0.0, "available": 0.0}


def update_paper_balance(asset, delta_balance, delta_locked=0.0):
    conn = get_connection()
    c = conn.cursor()
    c.execute("""
    UPDATE paper_wallet
    SET balance = balance + ?, locked = locked + ?
    WHERE asset = ?
    """, (delta_balance, delta_locked, asset))
    conn.commit()
    conn.close()


def set_paper_balance(asset, new_balance):
    conn = get_connection()
    c = conn.cursor()
    c.execute("INSERT OR REPLACE INTO paper_wallet (asset, balance, locked) VALUES (?, ?, 0.0)", (asset, float(new_balance)))
    conn.commit()
    conn.close()


# --- مدیریت معاملات ---
def save_new_trade(trade_data: dict):
    conn = get_connection()
    c = conn.cursor()
    now_ts = int(time.time())
    trade_id = trade_data.get("trade_id", f"TRD_{now_ts}_{trade_data.get('symbol', 'UNK')}")
    c.execute("""
    INSERT INTO trades (
        trade_id, symbol, market, side, mode, leverage,
        entry_price, amount, total_cost_irt, current_price,
        target_price, stop_loss, trailing_stop, break_even_active,
        dca_step, status, open_time, notes
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'OPEN', ?, ?)
    """, (
        trade_id,
        trade_data.get("symbol"),
        trade_data.get("market", "IRT"),
        trade_data.get("side", "BUY"),
        trade_data.get("mode", MODE_PAPER),
        trade_data.get("leverage", 1.0),
        trade_data.get("entry_price"),
        trade_data.get("amount"),
        trade_data.get("total_cost_irt"),
        trade_data.get("entry_price"),
        trade_data.get("target_price"),
        trade_data.get("stop_loss"),
        trade_data.get("stop_loss"),
        0,
        trade_data.get("dca_step", 0),
        now_ts,
        trade_data.get("notes", "")
    ))
    conn.commit()
    conn.close()
    return trade_id


def get_open_trades():
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT * FROM trades WHERE status = 'OPEN' ORDER BY open_time DESC")
    rows = [dict(r) for r in c.fetchall()]
    conn.close()
    return rows


def close_trade(trade_id, close_price, reason="TARGET_HIT"):
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT * FROM trades WHERE trade_id = ? AND status = 'OPEN'", (trade_id,))
    row = c.fetchone()
    if not row:
        conn.close()
        return None

    entry_price = row["entry_price"]
    amount = row["amount"]
    side = row["side"]
    leverage = row["leverage"]
    mode = row["mode"]
    now_ts = int(time.time())

    # محاسبه سود و زیان با احتساب ضریب اهرم و جهت پوزیشن
    if side in ["BUY", "LONG"]:
        pct_change = ((close_price - entry_price) / entry_price) * 100.0 * leverage
    else:  # SELL / SHORT
        pct_change = ((entry_price - close_price) / entry_price) * 100.0 * leverage

    cost = row["total_cost_irt"]
    pnl_irt = cost * (pct_change / 100.0)

    c.execute("""
    UPDATE trades
    SET status = 'CLOSED',
        current_price = ?,
        pnl_irt = ?,
        pnl_percent = ?,
        close_time = ?,
        close_reason = ?
    WHERE trade_id = ?
    """, (close_price, pnl_irt, pct_change, now_ts, reason, trade_id))

    # در حالت شبیه‌ساز، بازگشت سرمایه و سود به کیف پول مجازی
    if mode == MODE_PAPER:
        returned_irt = cost + pnl_irt
        c.execute("UPDATE paper_wallet SET balance = balance + ? WHERE asset = 'IRT'", (returned_irt,))

    # ثبت در آمار روزانه
    today_str = time.strftime("%Y-%m-%d")
    is_win = 1 if pnl_irt > 0 else 0
    is_loss = 1 if pnl_irt < 0 else 0

    c.execute("""
    INSERT INTO daily_stats (date_str, total_trades, winning_trades, losing_trades, total_pnl_irt, total_pnl_percent)
    VALUES (?, 1, ?, ?, ?, ?)
    ON CONFLICT(date_str) DO UPDATE SET
        total_trades = total_trades + 1,
        winning_trades = winning_trades + excluded.winning_trades,
        losing_trades = losing_trades + excluded.losing_trades,
        total_pnl_irt = total_pnl_irt + excluded.total_pnl_irt,
        total_pnl_percent = total_pnl_percent + excluded.total_pnl_percent
    """, (today_str, is_win, is_loss, pnl_irt, pct_change))

    # سوپاپ اضطراری اهرم: توقف خودکار ۲۴ ساعته در صورت ثبت ۲ ضرر متوالی در حالت اهرم
    if leverage > 1.0 and is_loss:
        c.execute("SELECT pnl_irt FROM trades WHERE leverage > 1.0 AND status = 'CLOSED' AND trade_id != ? ORDER BY close_time DESC LIMIT 1", (trade_id,))
        prev_margin = c.fetchone()
        if prev_margin and prev_margin["pnl_irt"] < 0:
            set_margin_enabled(False)
            set_setting("margin_consecutive_losses_paused", "1")

    conn.commit()
    conn.close()
    return {"trade_id": trade_id, "pnl_irt": pnl_irt, "pnl_percent": pct_change, "reason": reason}


def get_recent_trades(limit=10):
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT * FROM trades ORDER BY open_time DESC LIMIT ?", (limit,))
    rows = [dict(r) for r in c.fetchall()]
    conn.close()
    return rows


def update_trade_freerisk(trade_id: str, new_stop_loss: float):
    """انتقال حد ضرر به نقطه ورود (سامانه فری‌ریسک پویا)"""
    conn = get_connection()
    c = conn.cursor()
    c.execute("""
    UPDATE trades
    SET stop_loss = ?,
        notes = notes || ' | فری‌ریسک فعال شد'
    WHERE trade_id = ?
    """, (new_stop_loss, trade_id))
    conn.commit()
    conn.close()


def update_trade_dca(trade_id: str, new_entry_price: float, new_amount: float, added_cost: float, new_target: float, new_stop: float, new_step: int):
    """اعمال خرید پله‌ای و اصلاح میانگین ورود و تارگت"""
    conn = get_connection()
    c = conn.cursor()
    c.execute("""
    UPDATE trades
    SET entry_price = ?,
        amount = ?,
        total_cost_irt = total_cost_irt + ?,
        target_price = ?,
        stop_loss = ?,
        dca_step = ?,
        notes = notes || ' | خرید پله‌ای مرحله ' || ?
    WHERE trade_id = ?
    """, (new_entry_price, new_amount, added_cost, new_target, new_stop, new_step, str(new_step), trade_id))
    conn.commit()
    conn.close()


def check_daily_drawdown(max_drawdown_pct: float = 2.5) -> tuple:
    """بررسی سقف ضرر روزانه؛ بازگرداندن وضعیت مجاز بودن و درصد ضرر ثبت‌شده امروز"""
    today_str = time.strftime("%Y-%m-%d")
    conn = get_connection()
    c = conn.cursor()
    c.execute("SELECT total_pnl_percent FROM daily_stats WHERE date_str = ?", (today_str,))
    row = c.fetchone()
    conn.close()

    if not row:
        return True, 0.0

    today_pnl_pct = row["total_pnl_percent"] or 0.0
    # اگر زیان امروز بیشتر از سقف مجاز (مثلاً -۲.۵ درصد) باشد
    if today_pnl_pct <= -abs(max_drawdown_pct):
        return False, today_pnl_pct

    return True, today_pnl_pct


# راه‌اندازی اولیه خودکار دیتابیس هنگام فراخوانی ماژول
init_db()
