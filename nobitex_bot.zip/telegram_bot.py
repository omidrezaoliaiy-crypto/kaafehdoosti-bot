# -*- coding: utf-8 -*-
"""
ماژول ربات تلگرام اختصاصی نوبیتکس (هوشمند طلایی - @rmghnbot)
طراحی شده دقیقاً بر اساس چیدمان مصوب منوی ۸ دکمه‌ای ثابت
سازگار ۱۰۰ درصدی با صفحه‌خوان ان‌وی‌دی‌ای (NVDA)
بدون علائم نگارشی مزاحم، با دکمه‌های کاملاً متقارن و شفاف
"""

import urllib.request
import urllib.parse
import json
import time
import threading
from typing import Optional, Dict, Any, List

try:
    from .config import (
        TELEGRAM_BOT_TOKEN,
        MODE_PAPER,
        MODE_REAL,
        CAPITAL_PER_TRADE_PERCENT,
        TARGET_PROFIT_PERCENT,
        MAX_DAILY_DRAWDOWN_PERCENT,
        MIN_ORDER_VALUE_IRT,
        MAKER_FEE_PERCENT
    )
    from .database import (
        get_trading_mode,
        set_trading_mode,
        is_margin_enabled,
        set_margin_enabled,
        get_margin_max_multiplier,
        set_margin_max_multiplier,
        get_paper_balance,
        set_paper_balance,
        get_open_trades,
        get_recent_trades,
        get_setting,
        set_setting
    )
    from .nobitex_client import NobitexClient
    from .market_scanner import MarketScanner
except ImportError:
    from config import (
        TELEGRAM_BOT_TOKEN,
        MODE_PAPER,
        MODE_REAL,
        CAPITAL_PER_TRADE_PERCENT,
        TARGET_PROFIT_PERCENT,
        MAX_DAILY_DRAWDOWN_PERCENT,
        MIN_ORDER_VALUE_IRT,
        MAKER_FEE_PERCENT
    )
    from database import (
        get_trading_mode,
        set_trading_mode,
        is_margin_enabled,
        set_margin_enabled,
        get_margin_max_multiplier,
        set_margin_max_multiplier,
        get_paper_balance,
        set_paper_balance,
        get_open_trades,
        get_recent_trades,
        get_setting,
        set_setting
    )
    from nobitex_client import NobitexClient
    from market_scanner import MarketScanner


class TelegramBot:
    def __init__(self, token: str = TELEGRAM_BOT_TOKEN):
        self.token = token
        self.base_url = f"https://api.telegram.org/bot{self.token}"
        self.opener = urllib.request.build_opener()
        self.client = NobitexClient()
        self.scanner = MarketScanner(client=self.client)
        self.is_running = False
        self.last_update_id = 0

    def send_message(self, chat_id: int, text: str, reply_markup: Optional[dict] = None) -> bool:
        """ارسال پیام به تلگرام با فرمت متنی تمیز و بدون علائم نگارشی اضافه برای NVDA"""
        url = f"{self.base_url}/sendMessage"
        payload = {
            "chat_id": chat_id,
            "text": text
        }
        if reply_markup:
            payload["reply_markup"] = json.dumps(reply_markup)

        try:
            data = json.dumps(payload).encode("utf-8")
            req = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json"})
            with self.opener.open(req, timeout=15) as r:
                res = json.loads(r.read().decode("utf-8"))
                return res.get("ok", False)
        except Exception:
            return False

    def get_main_keyboard(self) -> dict:
        """
        منوی اصلی ثابت ۸ دکمه‌ای در ۴ ردیف متقارن و خوش‌دست:
        ردیف اول: شروع کن / توقف | وضعیت زنده ربات
        ردیف دوم: کیف پول | کارنامه و سود
        ردیف سوم: تنظیم حجم خرید | اتصال به نوبیتکس
        ردیف چهارم: انتخاب نوع بازار | فیلتر ریسک ارزها
        """
        keyboard = [
            ["شروع کن / توقف", "وضعیت زنده ربات"],
            ["کیف پول", "کارنامه و سود"],
            ["تنظیم حجم خرید", "اتصال به نوبیتکس"],
            ["انتخاب نوع بازار", "فیلتر ریسک ارزها"]
        ]
        return {"keyboard": keyboard, "resize_keyboard": True, "one_time_keyboard": False}

    def get_start_stop_keyboard(self) -> dict:
        """کیبورد شروع و توقف با تمرکز بر معامله آزمایشی ۱۰ میلیونی"""
        keyboard = [
            ["شروع معامله آزمایشی (با ۱۰ میلیون)", "توقف کامل معاملات"],
            ["شروع معامله واقعی (صرافی)", "بازگشت به منوی اصلی"]
        ]
        return {"keyboard": keyboard, "resize_keyboard": True}

    def get_wallet_keyboard(self) -> dict:
        """کیبورد مدیریت کیف پول با تفکیک دقیق حالت آزمایشی و واقعی"""
        keyboard = [
            ["کیف پول آزمایشی (شبیه‌ساز)", "کیف پول واقعی (صرافی نوبیتکس)"],
            ["شارژ کیف پول آزمایشی", "بازگشت به منوی اصلی"]
        ]
        return {"keyboard": keyboard, "resize_keyboard": True}

    def get_charge_keyboard(self) -> dict:
        """کیبورد مبالغ شارژ کیف پول آزمایشی"""
        keyboard = [
            ["شارژ ۱۰ میلیون تومان", "شارژ ۲۰ میلیون تومان"],
            ["شارژ ۵۰ میلیون تومان", "شارژ ۱۰۰ میلیون تومان"],
            ["بازگشت به کیف پول"]
        ]
        return {"keyboard": keyboard, "resize_keyboard": True}

    def get_market_type_keyboard(self) -> dict:
        """کیبورد انتخاب نوع بازار"""
        keyboard = [
            ["فقط بازار تومانی", "فقط بازار تتری"],
            ["هر دو بازار (تومانی و تتری)"],
            ["بازگشت به منوی اصلی"]
        ]
        return {"keyboard": keyboard, "resize_keyboard": True}

    def get_risk_filter_keyboard(self) -> dict:
        """کیبورد فیلتر ریسک ارزها و اهرم"""
        keyboard = [
            ["فقط ارزهای معتبر و کم‌ریسک", "تمام ارزهای فعال نوبیتکس"],
            ["تنظیمات اهرم و معاملات تعهدی"],
            ["بازگشت به منوی اصلی"]
        ]
        return {"keyboard": keyboard, "resize_keyboard": True}

    def get_leverage_keyboard(self) -> dict:
        """کیبورد تنظیمات ضرایب مجاز اهرم در نوبیتکس (حداکثر ضریب ۳)"""
        keyboard = [
            ["اهرم با ضریب ۱.۵", "اهرم با ضریب ۲"],
            ["اهرم با ضریب ۳"],
            ["خاموش کردن اهرم (فقط اسپات امن)"],
            ["بازگشت به منوی اصلی"]
        ]
        return {"keyboard": keyboard, "resize_keyboard": True}

    def get_capital_keyboard(self) -> dict:
        """کیبورد تنظیم درصد حجم خرید در هر معامله"""
        keyboard = [
            ["حجم معامله ۱۰ درصد", "حجم معامله ۱۵ درصد"],
            ["حجم معامله ۲۰ درصد"],
            ["بازگشت به منوی اصلی"]
        ]
        return {"keyboard": keyboard, "resize_keyboard": True}

    def get_connection_keyboard(self) -> dict:
        """کیبورد اختصاصی اتصال به نوبیتکس"""
        keyboard = [
            ["ثبت امن کلیدهای API نوبیتکس", "استعلام وضعیت اتصال صرافی"],
            ["بازگشت به منوی اصلی"]
        ]
        return {"keyboard": keyboard, "resize_keyboard": True}

    def handle_start_stop(self, chat_id: int):
        """دکمه ۱: شروع کن / توقف با گزینه مستقیم معامله آزمایشی ۱۰ میلیونی"""
        curr_active = "روشن و فعال" if get_setting("trading_active", "1") == "1" else "متوقف"
        mode = get_trading_mode()
        mode_str = "معامله آزمایشی (شبیه‌ساز)" if mode == MODE_PAPER else "معامله واقعی (صرافی)"
        wallet = get_paper_balance("IRT")
        balance = wallet.get("balance", 10000000.0)

        msg = (
            "مدیریت شروع و توقف معاملات:\n\n"
            f"وضعیت ربات: {curr_active}\n"
            f"حالت معامله: {mode_str}\n"
            f"موجودی کیف پول آزمایشی: {balance:,.0f} تومان\n\n"
            "برای شروع معامله آزمایشی بدون ریسک با ۱۰ میلیون تومان یا توقف معاملات، یکی از گزینه‌های زیر را انتخاب فرمایید:"
        )
        self.send_message(chat_id, msg, reply_markup=self.get_start_stop_keyboard())

    def handle_live_status(self, chat_id: int):
        """دکمه ۲: وضعیت زنده ربات"""
        mode = get_trading_mode()
        mode_str = "شبیه‌ساز تمرینی (بدون ریسک با ۱۰ میلیون تومان اعتبار)" if mode == MODE_PAPER else "واقعی (متصل به صرافی نوبیتکس)"
        bot_active = "روشن و در حال معامله" if get_setting("trading_active", "1") == "1" else "متوقف و موقت"
        market_type = get_setting("market_type", "تومانی")
        risk_mode = get_setting("risk_filter", "ارزهای معتبر و کم‌ریسک")
        margin_status = f"فعال با ضریب {get_margin_max_multiplier()}" if is_margin_enabled() else "خاموش (فقط اسپات امن)"

        # پایش نبض نوبیتکس
        t0 = time.time()
        stats = self.client.get_market_stats()
        latency = (time.time() - t0) * 1000

        btc_price_str = "در دسترس نیست"
        usdt_price_str = "در دسترس نیست"
        if stats:
            btc = stats.get("btc-rls", {})
            usdt = stats.get("usdt-rls", {})
            if btc.get("latest"):
                btc_price_str = f"{float(btc['latest']) / 10:,.0f} تومان"
            if usdt.get("latest"):
                usdt_price_str = f"{float(usdt['latest']) / 10:,.0f} تومان"

        msg = (
            "وضعیت زنده ربات معامله‌گر هوشمند:\n\n"
            f"وضعیت فعالیت: {bot_active}\n"
            f"حالت معامله: {mode_str}\n"
            f"نوع بازار فعال: {market_type}\n"
            f"فیلتر ریسک: {risk_mode}\n"
            f"معاملات تعهدی (اهرم): {margin_status}\n\n"
            "پایش لحظه‌ای نبض بازار نوبیتکس:\n"
            f"تاخیر سرور صرافی: {latency:.0f} میلی‌ثانیه (عالی و زیر ۱.۵ ثانیه)\n"
            f"قیمت بیت‌کوین: {btc_price_str}\n"
            f"قیمت تتر: {usdt_price_str}\n"
            "سوپاپ ضد سقوط: فعال و پایدار"
        )
        self.send_message(chat_id, msg, reply_markup=self.get_main_keyboard())

    def handle_wallet(self, chat_id: int):
        """دکمه ۳: کیف پول با تفکیک حالت آزمایشی و واقعی"""
        wallet = get_paper_balance("IRT")
        balance = wallet.get("balance", 0.0)

        msg = (
            "کیف پول و مدیریت دارایی:\n\n"
            "دو کیف پول مستقل برای شما تعبیه شده است:\n"
            f"۱. کیف پول آزمایشی (شبیه‌ساز): {balance:,.0f} تومان (بدون ریسک مالی)\n"
            "۲. کیف پول واقعی (صرافی نوبیتکس): موجودی حساب واقعی شما در صرافی\n\n"
            "برای مشاهده جزئیات هر کیف پول، یکی از دکمه‌های زیر را انتخاب فرمایید:"
        )
        self.send_message(chat_id, msg, reply_markup=self.get_wallet_keyboard())

    def handle_paper_wallet(self, chat_id: int):
        """مشاهده جزئیات کیف پول آزمایشی شبیه‌ساز"""
        wallet = get_paper_balance("IRT")
        balance = wallet.get("balance", 0.0)
        available = wallet.get("available", 0.0)
        in_trade = balance - available

        msg = (
            "کیف پول آزمایشی (شبیه‌ساز تستی):\n\n"
            f"کل دارایی فرضی: {balance:,.0f} تومان\n"
            f"موجودی آزاد برای معامله: {available:,.0f} تومان\n"
            f"سرمایه درگیر در معاملات باز: {in_trade:,.0f} تومان\n\n"
            "این کیف پول برای تست و بررسی عملکرد سودآوری ربات بدون به خطر افتادن حتی ۱ ریال پول واقعی است.\n"
            "در صورت نیاز به تغییر موجودی، دکمه «شارژ کیف پول آزمایشی» را بزنید."
        )
        self.send_message(chat_id, msg, reply_markup=self.get_wallet_keyboard())

    def handle_real_wallet(self, chat_id: int):
        """مشاهده وضعیت کیف پول واقعی صرافی نوبیتکس"""
        api_key = get_setting("nobitex_api_key", "")
        if not api_key:
            msg = (
                "کیف پول واقعی (صرافی نوبیتکس):\n\n"
                "کلیدهای API صرافی نوبیتکس هنوز متصل نشده‌اند.\n\n"
                "جهت حفظ ۱۰۰ درصدی امنیت دارایی شما، سیستم هم‌اکنون به صورت پیش‌فرض با کیف پول آزمایشی کار می‌کند.\n"
                "هر زمان که خواستید خرید و فروش واقعی در صرافی انجام شود، می‌توانید از دکمه «اتصال به نوبیتکس» در منوی اصلی کلیدهای خود را متصل فرمایید."
            )
        else:
            msg = "کیف پول واقعی متصل است و به صورت لحظه‌ای با وب‌سرویس صرافی همگام می‌شود."
        self.send_message(chat_id, msg, reply_markup=self.get_wallet_keyboard())

    def handle_trades_report(self, chat_id: int):
        """دکمه ۴: کارنامه و سود"""
        open_trades = get_open_trades()
        recent_trades = get_recent_trades(limit=5)

        total_profit = 0.0
        wins = 0
        losses = 0

        for t in recent_trades:
            if t["status"] == "closed":
                pnl = t.get("pnl_irt", 0.0) or 0.0
                total_profit += pnl
                if pnl > 0: wins += 1
                elif pnl < 0: losses += 1

        msg = (
            "کارنامه و گزارش معاملات:\n\n"
            f"تعداد معاملات باز فعلی: {len(open_trades)} معامله\n"
            f"سود خالص کل ذخیره‌شده: {total_profit:,.0f} تومان\n"
            f"معاملات برنده: {wins} | معاملات بازنده: {losses}\n"
            "تارگت سود هر معامله: ۳ درصد خالص پس از کسر کارمزد\n"
            "خروج زمانی خودکار: ۳.۵ ساعت در صورت درجا زدن\n\n"
        )

        if open_trades:
            msg += "معاملات باز در حال حاضر:\n"
            for tr in open_trades:
                msg += (
                    f"ارز {tr['symbol']}: خرید در {tr['entry_price']:,.0f} تومان | "
                    f"تارگت خروج ۱۰۰ درصدی: {tr['target_price']:,.0f} تومان | "
                    f"حد ضرر پویا: {tr['stop_loss']:,.0f} تومان\n"
                )
        else:
            msg += "در حال حاضر هیچ معامله بازی وجود ندارد و اسکنر در حال جستجوی ورود ایده‌آل است."

        self.send_message(chat_id, msg, reply_markup=self.get_main_keyboard())

    def handle_capital_settings(self, chat_id: int):
        """دکمه ۵: تنظیم حجم خرید"""
        cap_pct = get_setting("capital_per_trade_percent", str(CAPITAL_PER_TRADE_PERCENT))
        msg = (
            "تنظیمات حجم خرید و مدیریت ریسک:\n\n"
            f"سهم هر معامله از کل سرمایه: {cap_pct} درصد\n"
            "حداقل مبلغ قانونی هر سفارش در نوبیتکس: ۳۰۰ هزار تومان\n"
            "حد ضرر پویا: بر اساس ۲ برابر دامنه نوسان واقعی (ATR)\n"
            "سقف ضرر مجاز روزانه: ۲.۵ درصد (با توقف اضطراری ۲۴ ساعته)\n"
            "سود مرکب: فعال (سودها خودکار به اصل سرمایه افزوده می‌شوند)\n\n"
            "برای تغییر سهم سرمایه در هر پوزیشن، گزینه‌های زیر را انتخاب فرمایید:"
        )
        self.send_message(chat_id, msg, reply_markup=self.get_capital_keyboard())

    def handle_nobitex_connection(self, chat_id: int):
        """دکمه ۶: اتصال به نوبیتکس"""
        api_key = get_setting("nobitex_api_key", "")
        status_str = "کلید API ثبت شده است" if api_key else "در انتظار ثبت کلید API"
        msg = (
            "اتصال به صرافی نوبیتکس:\n\n"
            f"وضعیت اتصال: {status_str}\n\n"
            "در این بخش می‌توانید کلیدهای API اختصاصی خود را ثبت و وضعیت ارتباط با سرور صرافی را بررسی فرمایید.\n"
            "یکی از گزینه‌های زیر را انتخاب کنید:"
        )
        self.send_message(chat_id, msg, reply_markup=self.get_connection_keyboard())

    def handle_market_type(self, chat_id: int):
        """دکمه ۷: انتخاب نوع بازار"""
        curr = get_setting("market_type", "تومانی")
        msg = (
            f"انتخاب نوع بازار معامله (وضعیت فعلی: {curr}):\n\n"
            "گزینه اول: فقط بازار تومانی (خرید و فروش با ریال و تومان)\n"
            "گزینه دوم: فقط بازار تتری (معاملات دلاری با استیبل‌کوین USDT)\n"
            "گزینه سوم: هر دو بازار (شکار فرصت‌ها و آربیتراژ بین تومانی و تتری)\n\n"
            "گزینه دلخواه را از کلیدهای زیر انتخاب کنید:"
        )
        self.send_message(chat_id, msg, reply_markup=self.get_market_type_keyboard())

    def handle_risk_filter(self, chat_id: int):
        """دکمه ۸: فیلتر ریسک ارزها"""
        curr_risk = get_setting("risk_filter", "فقط ارزهای معتبر و کم‌ریسک")
        curr_margin = "روشن" if is_margin_enabled() else "خاموش"
        msg = (
            f"فیلتر ریسک ارزها و استراتژی اهرم:\n\n"
            f"فیلتر فعلی انتخاب ارزها: {curr_risk}\n"
            f"وضعیت معاملات تعهدی و اهرم: {curr_margin}\n\n"
            "ارزهای معتبر و کم‌ریسک: بیت‌کوین، اتریوم، تتر، سولانا، تون، دوج‌کوین و کاردانو\n"
            "تمام ارزها: بررسی تمامی رمزارزهای فعال نوبیتکس با شرط داشتن حجم و اسپرد زیر ۰.۵ درصد\n\n"
            "گزینه مورد نظر را انتخاب فرمایید:"
        )
        self.send_message(chat_id, msg, reply_markup=self.get_risk_filter_keyboard())

    def process_message(self, message: dict):
        """پردازش هوشمند تمام پیام‌ها و کلیدهای منوی ۸ تایی"""
        chat_id = message.get("chat", {}).get("id")
        text = message.get("text", "").strip()

        if not chat_id or not text:
            return

        # ذخیره آخرین شناسه ادمین تلگرام
        set_setting("telegram_admin_id", str(chat_id))

        if text == "/start":
            welcome_msg = (
                "به ربات هوشمند طلایی نوبیتکس خوش آمدید!\n\n"
                "منوی اختصاصی شما با همان چیدمان ثابت و منظم ۸ دکمه‌ای در ۴ ردیف دوتایی برایتان باز شد:\n\n"
                "ردیف اول: شروع کن / توقف | وضعیت زنده ربات\n"
                "ردیف دوم: کیف پول | کارنامه و سود\n"
                "ردیف سوم: تنظیم حجم خرید | اتصال به نوبیتکس\n"
                "ردیف چهارم: انتخاب نوع بازار | فیلتر ریسک ارزها\n\n"
                "تمام دکمه‌ها کاملاً خوانا برای ان‌وی‌دی‌ای طراحی شده‌اند. با کلیدهای جهت‌نما یا تب بین دکمه‌ها حرکت کنید."
            )
            self.send_message(chat_id, welcome_msg, reply_markup=self.get_main_keyboard())

        # ردیف اول: شروع و توقف و وضعیت
        elif text == "شروع کن / توقف":
            self.handle_start_stop(chat_id)

        elif "شروع معامله آزمایشی" in text or "معامله آزمایشی" in text:
            set_trading_mode(MODE_PAPER)
            set_setting("trading_active", "1")
            wallet = get_paper_balance("IRT")
            if wallet.get("available", 0.0) < MIN_ORDER_VALUE_IRT:
                set_paper_balance("IRT", 10000000.0)
            msg = (
                "معامله آزمایشی با موفقیت شروع شد!\n\n"
                "اعتبار کیف پول شبیه‌ساز: ۱۰ میلیون تومان پول فرضی (بدون ریسک ۱ ریال پول واقعی).\n"
                "سرمایه در هر معامله: حداکثر ۱۵ درصد (۱.۵ میلیون تومان).\n"
                "تارگت سود خالص خروج: ۳ درصد با کسر کارمزد میکر صرافی.\n"
                "حد ضرر پویا: فعال بر اساس دامنه نوسان واقعی (ATR).\n\n"
                "اسکنر ۲۴ ساعته نوبیتکس هم‌اکنون روشن است و به محض شکار اولین موقعیت، پیام خرید را در تلگرام دریافت خواهید کرد."
            )
            self.send_message(chat_id, msg, reply_markup=self.get_main_keyboard())

        elif "توقف کامل معاملات" in text or text == "توقف معاملات":
            set_setting("trading_active", "0")
            msg = (
                "معاملات با موفقیت متوقف شد.\n\n"
                "اسکنر بازار به حالت آماده‌باش رفت و هیچ خرید جدیدی انجام نمی‌شود.\n"
                "معاملات قبلی شما در پایگاه داده امن باقی می‌مانند."
            )
            self.send_message(chat_id, msg, reply_markup=self.get_main_keyboard())

        elif "شروع معامله واقعی" in text:
            set_trading_mode(MODE_REAL)
            set_setting("trading_active", "1")
            msg = (
                "حالت معاملات واقعی (صرافی نوبیتکس) فعال شد.\n"
                "سفارشات جدید در صورت تایید فیلترها روی حساب صرافی ثبت می‌شوند."
            )
            self.send_message(chat_id, msg, reply_markup=self.get_main_keyboard())

        elif "وضعیت زنده ربات" in text or "وضعیت زنده" in text:
            self.handle_live_status(chat_id)

        # ردیف دوم: کیف پول و کارنامه
        elif text == "کیف پول" or text == "بازگشت به کیف پول":
            self.handle_wallet(chat_id)

        elif "کیف پول آزمایشی" in text:
            self.handle_paper_wallet(chat_id)

        elif "کیف پول واقعی" in text:
            self.handle_real_wallet(chat_id)

        elif "شارژ کیف پول آزمایشی" in text or "شارژ حساب آزمایشی" in text:
            wallet = get_paper_balance("IRT")
            balance = wallet.get("balance", 0.0)
            msg = (
                f"شارژ کیف پول آزمایشی (موجودی فعلی: {balance:,.0f} تومان):\n\n"
                "لطفاً مبلغ مورد نظر برای شارژ مجازی را انتخاب کنید:"
            )
            self.send_message(chat_id, msg, reply_markup=self.get_charge_keyboard())

        elif "کارنامه و سود" in text or "کارنامه" in text:
            self.handle_trades_report(chat_id)

        # ردیف سوم
        elif "تنظیم حجم خرید" in text or "حجم خرید" in text:
            self.handle_capital_settings(chat_id)

        elif "اتصال به نوبیتکس" in text:
            self.handle_nobitex_connection(chat_id)

        # ردیف چهارم
        elif "انتخاب نوع بازار" in text:
            self.handle_market_type(chat_id)

        elif "فیلتر ریسک ارزها" in text:
            self.handle_risk_filter(chat_id)

        # زیرمنوهای کیف پول (شارژ)
        elif "شارژ" in text and "میلیون تومان" in text:
            amount = 10000000.0
            if "۱۰" in text: amount = 10000000.0
            elif "۲۰" in text: amount = 20000000.0
            elif "۵۰" in text: amount = 50000000.0
            elif "۱۰۰" in text: amount = 100000000.0
            set_paper_balance("IRT", amount)
            msg = f"کیف پول شبیه‌ساز با موفقیت شارژ شد. موجودی جدید: {amount:,.0f} تومان."
            self.send_message(chat_id, msg, reply_markup=self.get_main_keyboard())

        # زیرمنوهای نوع بازار
        elif "فقط بازار تومانی" in text:
            set_setting("market_type", "فقط بازار تومانی")
            self.send_message(chat_id, "نوع بازار به «فقط بازار تومانی» تغییر یافت.", reply_markup=self.get_main_keyboard())

        elif "فقط بازار تتری" in text:
            set_setting("market_type", "فقط بازار تتری")
            self.send_message(chat_id, "نوع بازار به «فقط بازار تتری» تغییر یافت.", reply_markup=self.get_main_keyboard())

        elif "هر دو بازار" in text:
            set_setting("market_type", "هر دو بازار (تومانی و تتری)")
            self.send_message(chat_id, "نوع بازار به «هر دو بازار (تومانی و تتری)» با فعال‌سازی آربیتراژ تغییر یافت.", reply_markup=self.get_main_keyboard())

        # زیرمنوهای فیلتر ریسک
        elif "فقط ارزهای معتبر و کم‌ریسک" in text:
            set_setting("risk_filter", "فقط ارزهای معتبر و کم‌ریسک")
            self.send_message(chat_id, "فیلتر ریسک به «فقط ارزهای معتبر و کم‌ریسک» تنظیم شد.", reply_markup=self.get_main_keyboard())

        elif "تمام ارزهای فعال نوبیتکس" in text:
            set_setting("risk_filter", "تمام ارزهای فعال نوبیتکس")
            self.send_message(chat_id, "فیلتر ریسک به «تمام ارزهای فعال نوبیتکس» با فیلتر اسپرد زیر ۰.۵ درصد تنظیم شد.", reply_markup=self.get_main_keyboard())

        # زیرمنوی اهرم
        elif "تنظیمات اهرم و معاملات تعهدی" in text:
            curr_margin = "روشن" if is_margin_enabled() else "خاموش"
            msg = f"تنظیمات اهرم و معاملات تعهدی (وضعیت فعلی: {curr_margin}):\n\nیک ضریب را انتخاب فرمایید:"
            self.send_message(chat_id, msg, reply_markup=self.get_leverage_keyboard())

        elif "اهرم با ضریب" in text:
            mult = 2.0
            if "۱.۵" in text: mult = 1.5
            elif "۲" in text: mult = 2.0
            elif "۳" in text: mult = 3.0
            elif "۵" in text: mult = 5.0
            set_margin_enabled(True)
            set_margin_max_multiplier(mult)
            msg = f"معاملات تعهدی و اهرم با ضریب {mult} و رعایت فاصله ۷۰ درصدی از لیکوییدی فعال شد."
            self.send_message(chat_id, msg, reply_markup=self.get_main_keyboard())

        elif "خاموش کردن اهرم" in text:
            set_margin_enabled(False)
            self.send_message(chat_id, "معاملات تعهدی خاموش شد. ربات روی معاملات اسپات امن کار خواهد کرد.", reply_markup=self.get_main_keyboard())

        # زیرمنوی حجم معامله
        elif "حجم معامله" in text:
            pct = 15.0
            if "۱۰" in text: pct = 10.0
            elif "۱۵" in text: pct = 15.0
            elif "۲۰" in text: pct = 20.0
            set_setting("capital_per_trade_percent", str(pct))
            msg = f"حجم هر معامله به {pct:.0f} درصد از کل سرمایه تنظیم گردید."
            self.send_message(chat_id, msg, reply_markup=self.get_main_keyboard())

        # زیرمنوی اتصال به نوبیتکس
        elif "تغییر به معاملات با پول واقعی" in text:
            set_trading_mode(MODE_REAL)
            msg = "حالت معامله به حالت واقعی (صرافی نوبیتکس) تغییر یافت. سفارشات واقعی ثبت خواهند شد."
            self.send_message(chat_id, msg, reply_markup=self.get_main_keyboard())

        elif "تغییر به حالت شبیه‌ساز" in text:
            set_trading_mode(MODE_PAPER)
            msg = "ربات به حالت شبیه‌ساز و تمرینی بازگشت. هیچ پولی به خطر نخواهد افتاد."
            self.send_message(chat_id, msg, reply_markup=self.get_main_keyboard())

        elif "ثبت امن کلیدهای API" in text:
            msg = (
                "ثبت امن کلیدهای نوبیتکس:\n\n"
                "برای اتصال به نوبیتکس، کلیدها در پایگاه داده محلی ذخیره می‌شوند.\n"
                "در حال حاضر به دلیل رعایت امنیت و حالت شبیه‌ساز، نیازی به ثبت کلید واقعی ندارید و می‌توانید ربات را کاملاً تستی با قیمت‌های زنده بررسی فرمایید."
            )
            self.send_message(chat_id, msg, reply_markup=self.get_connection_keyboard())

        elif "استعلام وضعیت اتصال" in text:
            api_key = get_setting("nobitex_api_key", "")
            if api_key:
                msg = "وب‌سرویس رسمی نوبیتکس متصل است و احراز هویت با موفقیت انجام شد."
            else:
                msg = (
                    "وضعیت وب‌سرویس نوبیتکس:\n\n"
                    "ارتباط زنده با وب‌سرویس نوبیتکس برقرار و پایدار است.\n"
                    "کلید API شخصی هنوز ثبت نشده و سیستم برای امنیت شما در حالت شبیه‌ساز فعالیت می‌کند."
                )
            self.send_message(chat_id, msg, reply_markup=self.get_connection_keyboard())

        elif "بازگشت به منوی اصلی" in text:
            self.send_message(chat_id, "به منوی اصلی بازگشتید.", reply_markup=self.get_main_keyboard())

        else:
            self.send_message(chat_id, "دستور نامشخص است. لطفاً از ۸ کلید منوی زیر استفاده کنید:", reply_markup=self.get_main_keyboard())

    def run_polling(self):
        """حلقه دریافت آپدیت‌ها از تلگرام (Long Polling)"""
        self.is_running = True
        print(f"ربات تلگرام نوبیتکس با منوی ۸ دکمه‌ای فعال شد (توکن {self.token[:10]}...).", flush=True)

        while self.is_running:
            url = f"{self.base_url}/getUpdates?offset={self.last_update_id + 1}&timeout=15"
            try:
                req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
                with self.opener.open(req, timeout=20) as r:
                    res = json.loads(r.read().decode("utf-8"))
                    if res.get("ok"):
                        for update in res.get("result", []):
                            self.last_update_id = update["update_id"]
                            if "message" in update:
                                self.process_message(update["message"])
            except Exception:
                time.sleep(2)
            time.sleep(0.5)


if __name__ == "__main__":
    bot = TelegramBot()
    bot.run_polling()
