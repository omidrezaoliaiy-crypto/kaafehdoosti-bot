import sys
import os

# اضافه کردن مسیر پروژه به مسیر پایتون
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from nobitex_client import NobitexClient
from indicators import calculate_rsi, calculate_ema, calculate_atr, detect_bullish_divergence
import database

print("--- تست ماژول پایگاه داده ---")
print("حالت معامله فعلی:", database.get_trading_mode())
print("موجودی کیف پول شبیه‌ساز:", database.get_paper_balance("IRT"))

print("\n--- تست وب‌سرویس زنده نوبیتکس ---")
client = NobitexClient()
stats = client.get_market_stats()
if stats:
    print(f"آمار بازارها دریافت شد! تعداد بازارها: {len(stats)}")
    # نمونه قیمت تتر و بیت‌کوین
    btc = stats.get("btc-rls", {})
    usdt = stats.get("usdt-rls", {})
    if btc:
        btc_price_irt = float(btc.get("latest", 0)) / 10.0
        print(f"قیمت زنده بیت‌کوین به تومان: {btc_price_irt:,.0f} تومان")
    if usdt:
        usdt_price_irt = float(usdt.get("latest", 0)) / 10.0
        print(f"قیمت زنده تتر به تومان: {usdt_price_irt:,.0f} تومان")
else:
    print("خطا در دریافت آمار بازار نوبیتکس")

print("\n--- تست دریافت کندل و محاسبه اندیکاتورها ---")
candles = client.get_candles("BTCIRT", resolution="15", count_back=30)
if candles and candles.get("close"):
    closes = [float(c) for c in candles["close"]]
    highs = [float(h) for h in candles["high"]]
    lows = [float(l) for l in candles["low"]]
    print(f"تعداد کندل‌های ۱۵ دقیقه‌ای دریافت شده: {len(closes)}")
    
    rsi = calculate_rsi(closes)
    if rsi:
        print(f"شاخص آر اس آی (RSI) فعلی بیت‌کوین: {rsi[-1]:.2f}")
        
    ema21 = calculate_ema(closes, 21)
    if ema21:
        print(f"میانگین متحرک ۲۱ (EMA 21): {ema21[-1]:,.0f}")
        
    atr = calculate_atr(highs, lows, closes)
    if atr:
        print(f"شاخص نوسان (ATR 14): {atr[-1]:,.0f}")
        
    has_div, div_type = detect_bullish_divergence(closes, rsi if rsi else [])
    print(f"وضعیت واگرایی مثبت: {has_div} ({div_type})")
else:
    print("خطا در دریافت کندل‌ها یا فرمت داده‌ها")

print("\nتست با موفقیت به پایان رسید.")
